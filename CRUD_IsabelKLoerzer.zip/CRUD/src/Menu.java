public class Menu {
    
    /**
	 * Función que presenta el menú.
	 */
	public static void menu() {

		System.out.println(
				 "\n===================" 
                 + "\n1. Crear tablas" 
                 + "\n2. Insertar datos"
                 +"\n3. Modificar datos"
                 +"\n4. Listar datos"
                 +"\n5. Borrar datos"
                 +"\n6. Salir");

	}
}
