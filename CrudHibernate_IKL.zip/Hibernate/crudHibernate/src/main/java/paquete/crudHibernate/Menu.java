package paquete.crudHibernate;

public class Menu {

	public static void menu() {

		System.out.println(
				 "\n===================" 
                 + "\n1. Listar usuarios" 
                 + "\n2. Insertar usuario"
                 +"\n3. Modificar usuario"
                 +"\n4. Mostrar datos de un usuario"
                 +"\n5. Borrar usuario"
                 +"\n6. Salir");

	}
}
